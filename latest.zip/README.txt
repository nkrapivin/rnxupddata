-- RUSSELLNX VERSION 1.3.5 README --

Hi!
Let me explain why there are other files/folders other than just RussellNX.exe

runners - it's a directory with prebuilt GMS2 Runners, don't touch it.
hacbrewpack.exe - it's a tool that builds NSP.
hptnacp.exe - it's a tool that makes control.nacp
license - it's a folder that contains GMS2 license files to fool GMAssetCompiler, DO NOT DELETE IT!

Meow!

Credits:
Nik - making this tool
YoYoGays (YoYoGames) - making GameMaker Studio 2
TheRadziu - beta testing on a real switch
PlastoPyC - uwu-ing
Nintendo - making NintendoSDK (not included here, sorry!)